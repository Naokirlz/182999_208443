﻿using System.Collections.Generic;

namespace Incidentes.DTOs
{
    public class AsignacionesDTO
    {
        public List<int> UsuarioId { get; set; }
        public int ProyectoId { get; set; }
    }
}
