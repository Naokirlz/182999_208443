﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Incidentes.DTOs
{
    public class FuenteDTO
    {
        public string rutaFuente { get; set; }
        public string rutaBinario { get; set; }
        public int usuarioId { get; set; }
    }
}
