﻿namespace Incidentes.WebApi.DTOs
{
    public class ProyectoParaReporteDTO
    {
        public int Id { get; set; }
        public string Nombre { get; set; }
        public int CantidadDeIncidentes { get; set; }
    }
}
