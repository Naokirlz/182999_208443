﻿namespace Incidentes.WebApi.DTOs
{
    public class ImportacionesDTO
    {
        public string Ruta { get; set; }
    }
}
